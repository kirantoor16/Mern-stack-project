books and notes reference
two panel
admin 
student


admin - add quiz, branch, course, question etc
student add material(notes, ebooks, files etc ) and play quiz


admin panel
login
admin@gmail.com
123